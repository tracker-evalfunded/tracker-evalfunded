# 📊 Tracker Cuentas Espejadas

Sistema de tracking para evaluaciones de prop firms con cuentas espejadas.
Soporta sistemas de **$25K** y **$50K** con tres fases: **Eval → Funded → Ordeño**.

## 🎯 Características

- **Sistema configurable** $25K o $50K por cada journal
- **7 roles automáticos** por saldo (Quemada, Riesgo, Rezagada, Base, Empuje, Encubadora, Funded)
- **Cruces espejados** con detección automática del tipo
- **Reciclaje de rezagadas** y cruce final de encubadoras
- **Fase Funded**: cuentas resetean a $25k/$50k para concentrar capital
- **Fase Ordeño**: configurable días + monto/día con tracking de pagos
- **Persistencia local** con localStorage
- **Exportación a imagen PNG**
- **Múltiples journals** con fechas y nombres custom

## 🚀 Instalación local

```bash
# Clonar repo
git clone <tu-repo-url>
cd tracker-cuentas-espejadas

# Instalar dependencias
npm install

# Correr en desarrollo
npm run dev

# Build para producción
npm run build
```

Después de `npm run dev`, abre [http://localhost:5173](http://localhost:5173)

## 📦 Deploy gratis

### Vercel (recomendado)

1. Sube el repo a GitHub
2. Ve a [vercel.com](https://vercel.com) e importa el repo
3. Vercel detecta Vite automáticamente — solo presiona Deploy
4. Te da una URL pública gratis

### Netlify

1. Sube el repo a GitHub
2. Ve a [netlify.com](https://netlify.com) e importa el repo
3. Build command: `npm run build`
4. Publish directory: `dist`

### GitHub Pages

```bash
npm install --save-dev gh-pages
```

Agrega a `package.json`:
```json
"scripts": {
  "deploy": "npm run build && gh-pages -d dist"
}
```

Ejecuta:
```bash
npm run deploy
```

## 📱 Usar como app en celular

Una vez deployado:
1. Abre la URL en Safari (iPhone) o Chrome (Android)
2. Compartir → "Añadir a pantalla de inicio"
3. Se comporta como app nativa

## 💾 Datos

Los journals se guardan en `localStorage` del navegador:
- **No se comparten** entre dispositivos
- **Se mantienen** mientras no borres caché del navegador
- Cada navegador/dispositivo tiene su propio almacenamiento

## 📊 Reglas del sistema

### $25K
| Concepto | Valor |
|---|---|
| DD | $1,000 |
| Riesgo/trade | $500 |
| Cruce final | $500 |
| Quema | $24,000 |
| Funded | $26,500 |
| Ordeño desde | $26,000 |

### $50K
| Concepto | Valor |
|---|---|
| DD | $2,000 |
| Riesgo/trade | $1,000 |
| Cruce final | $1,000 |
| Quema | $48,000 |
| Funded | $53,000 |
| Ordeño desde | $52,000 |

## 🛠 Stack

- **React 18**
- **Vite** (build tool)
- **localStorage** para persistencia
- Sin dependencias externas adicionales

## 📄 Licencia

Personal use.
