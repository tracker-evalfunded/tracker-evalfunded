import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'

// localStorage adapter to mimic window.storage API used by the tracker
if (typeof window !== 'undefined' && !window.storage) {
  const PREFIX = 'tracker_';
  window.storage = {
    async set(key, value) {
      try {
        localStorage.setItem(PREFIX + key, value);
        return { key, value };
      } catch (e) { return null; }
    },
    async get(key) {
      try {
        const value = localStorage.getItem(PREFIX + key);
        if (value === null) throw new Error('not found');
        return { key, value };
      } catch (e) { throw e; }
    },
    async delete(key) {
      try {
        localStorage.removeItem(PREFIX + key);
        return { key, deleted: true };
      } catch (e) { return null; }
    },
    async list(prefix) {
      try {
        const keys = [];
        const fullPrefix = PREFIX + (prefix || '');
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith(fullPrefix)) keys.push(k.slice(PREFIX.length));
        }
        return { keys, prefix };
      } catch (e) { return null; }
    },
  };
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
